/**
 * NOTE FOR USER:
 * This file contains the Server-Side code you requested for Next.js.
 * Since this is a client-side preview, this code is commented out to prevent build errors.
 * Copy these sections into your actual Next.js project structure (e.g., /app/api/...).
 */

/*
// ==========================================
// FILE: /lib/supabaseServer.ts
// ==========================================
import { createClient } from '@supabase/supabase-js';

export const supabaseAdmin = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

// ==========================================
// FILE: /lib/ensureProfile.ts
// ==========================================
import { supabaseAdmin } from './supabaseServer';

export async function ensureProfile(user: { id: string; email?: string; name?: string; image?: string }) {
  const { data } = await supabaseAdmin
    .from('profiles')
    .select('id')
    .eq('id', user.id)
    .single();

  if (!data) {
    await supabaseAdmin.from('profiles').insert({
      id: user.id,
      email: user.email,
      full_name: user.name,
      avatar_url: user.image,
    });
  }
}

// ==========================================
// FILE: /app/api/chat/route.ts
// ==========================================
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/authOptions';
import { supabaseAdmin } from '@/lib/supabaseServer';
import { ensureProfile } from '@/lib/ensureProfile';

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return new NextResponse('Unauthorized', { status: 401 });

  const { message, conversationId } = await req.json();
  await ensureProfile(session.user as any);

  const userId = (session.user as any).id;
  let currentConversationId = conversationId;
  let vfUserId = '';

  // 1. Handle Conversation Creation/Retrieval
  if (!currentConversationId) {
    const { data: conv, error } = await supabaseAdmin
      .from('conversations')
      .insert({
        user_id: userId,
        vf_user_id: 'temp', // Placeholder
      })
      .select()
      .single();

    if (error) return new NextResponse(error.message, { status: 500 });
    
    currentConversationId = conv.id;
    vfUserId = `${userId}--${currentConversationId}`;

    // Update with actual VF ID
    await supabaseAdmin
      .from('conversations')
      .update({ vf_user_id: vfUserId })
      .eq('id', currentConversationId);
  } else {
    const { data: conv } = await supabaseAdmin
      .from('conversations')
      .select('vf_user_id')
      .eq('id', currentConversationId)
      .eq('user_id', userId)
      .single();
      
    if (!conv) return new NextResponse('Conversation not found', { status: 404 });
    vfUserId = conv.vf_user_id;
  }

  // 2. Store User Message
  await supabaseAdmin.from('messages').insert({
    conversation_id: currentConversationId,
    sender_role: 'user',
    content: message,
  });

  // 3. Update Title if needed
  // Logic to check if title is null and update it with substring of message...

  // 4. Call Voiceflow
  const vfResponse = await fetch(
    `https://general-runtime.voiceflow.com/state/user/${encodeURIComponent(vfUserId)}/interact`,
    {
      method: 'POST',
      headers: {
        Authorization: process.env.VF_API_KEY!,
        versionID: process.env.VF_VERSION_ID || 'production',
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({
        request: {
          type: 'text',
          payload: message
        }
      })
    }
  );

  const traces = await vfResponse.json();

  // 5. Parse Voiceflow Response
  let assistantReply = '';
  // Filter for text traces and concatenate
  traces.forEach((trace: any) => {
    if (trace.type === 'text' || trace.type === 'speak') {
       assistantReply += trace.payload.message + ' ';
    }
  });

  // 6. Store Assistant Message
  await supabaseAdmin.from('messages').insert({
    conversation_id: currentConversationId,
    sender_role: 'assistant',
    content: assistantReply.trim(),
    metadata: traces
  });

  return NextResponse.json({ 
    reply: assistantReply.trim(), 
    conversationId: currentConversationId 
  });
}
*/

export const API_DOCUMENTATION = "See this file for the server-side implementation code.";