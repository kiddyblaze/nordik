import { supabaseAdmin } from './supabaseServer';

export async function ensureProfile(user: { id: string; email?: string; name?: string; image?: string }) {
  // Check if profile exists
  const { data } = await supabaseAdmin
    .from('profiles')
    .select('id')
    .eq('id', user.id)
    .single();

  if (!data) {
    // Insert new profile
    const { error } = await supabaseAdmin.from('profiles').insert({
      id: user.id,
      email: user.email,
      full_name: user.name,
      avatar_url: user.image,
    });

    if (error) {
      console.error('Error creating profile:', error);
    }
  }
}