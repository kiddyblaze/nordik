import type { Metadata } from 'next';
import { Urbanist } from 'next/font/google';
import './globals.css';
import Providers from './providers';

const urbanist = Urbanist({ 
  subsets: ['latin'],
  variable: '--font-urbanist',
});

export const metadata: Metadata = {
  title: 'Nordik Assistant',
  description: 'Internal AI Assistant for Nordik Recovery',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={urbanist.variable}>
      <body className="bg-nordik-ivory text-nordik-dark dark:bg-nordik-dark dark:text-nordik-ivory">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}