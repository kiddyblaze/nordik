'use client';

import { signIn } from "next-auth/react";
import { useState } from "react";
import { Loader2, Sparkles } from "lucide-react";

export default function LoginPage() {
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    setIsLoading(true);
    await signIn('google', { callbackUrl: '/' });
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-nordik-ivory dark:bg-nordik-dark p-4 relative overflow-hidden">
        {/* Background Decorations */}
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-nordik-taupe opacity-10 dark:opacity-5 blur-3xl"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] rounded-full bg-nordik-clay dark:bg-black opacity-5 dark:opacity-20 blur-3xl"></div>

        <div className="z-10 w-full max-w-md text-center">
          <div className="mb-12 animate-fade-in-up">
             <h1 className="text-6xl font-semibold text-nordik-dark dark:text-nordik-ivory tracking-tighter mb-3 transition-colors">nordik</h1>
             <p className="text-sm font-bold text-nordik-clay dark:text-nordik-taupe uppercase tracking-[0.5em] transition-colors">Recovery Assistant</p>
          </div>

          <div className="bg-white/80 dark:bg-nordik-dark-surface/60 backdrop-blur-lg p-8 rounded-3xl shadow-soft border border-white/50 dark:border-white/5 transition-all duration-300">
            <p className="text-gray-600 dark:text-nordik-light/80 mb-8 font-medium leading-relaxed">
              Internal AI tool for the Nordik team. <br/>Log in to access the knowledge base.
            </p>
            
            <button 
              onClick={handleLogin}
              disabled={isLoading}
              className="w-full group bg-nordik-dark hover:bg-black dark:bg-nordik-ivory dark:text-nordik-dark dark:hover:bg-white text-white font-semibold py-4 px-6 rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-0.5 flex items-center justify-center gap-3"
            >
              {isLoading ? (
                <Loader2 className="animate-spin" />
              ) : (
                <>
                  <svg className="w-5 h-5 transition-transform group-hover:scale-110" viewBox="0 0 24 24">
                    <path fill="currentColor" d="M21.35,11.1H12.18V13.83H18.69C18.36,17.64 15.19,19.27 12.19,19.27C8.36,19.27 5,16.25 5,12.61C5,8.85 8.38,5.78 12.23,5.78C14.61,5.78 16.28,6.81 17.15,7.65L19.16,5.66C17.31,3.92 14.76,2.92 12.18,2.92C6.85,2.92 2.5,7.26 2.5,12.61C2.5,17.96 6.85,22.3 12.18,22.3C16.91,22.3 21.5,18.35 21.5,12.91C21.5,11.76 21.35,11.1 21.35,11.1V11.1Z" />
                  </svg>
                  <span>Sign in with Google</span>
                </>
              )}
            </button>
          </div>
          
          <div className="mt-12 flex items-center justify-center gap-2 text-nordik-taupe/60 dark:text-nordik-taupe/40">
             <Sparkles size={12} />
             <p className="text-[10px] uppercase tracking-widest">Powered by Voiceflow</p>
          </div>
        </div>
      </div>
  );
}