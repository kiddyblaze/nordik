import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/authOptions';
import { supabaseAdmin } from '@/lib/supabaseServer';

export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return new NextResponse('Unauthorized', { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const conversationId = searchParams.get('conversationId');

  if (!conversationId) {
    return new NextResponse('Missing conversationId', { status: 400 });
  }

  const userId = (session.user as any).id;

  // Verify ownership
  const { data: conversation, error: convError } = await supabaseAdmin
    .from('conversations')
    .select('id')
    .eq('id', conversationId)
    .eq('user_id', userId)
    .single();

  if (convError || !conversation) {
    return new NextResponse('Conversation not found or unauthorized', { status: 404 });
  }

  // Fetch messages
  const { data, error } = await supabaseAdmin
    .from('messages')
    .select('id, sender_role, content, created_at')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  // Map DB format to frontend format
  const messages = data.map((msg: any) => ({
    id: msg.id,
    role: msg.sender_role, // DB uses 'sender_role', frontend uses 'role'
    content: msg.content,
    created_at: msg.created_at
  }));

  return NextResponse.json({ messages });
}