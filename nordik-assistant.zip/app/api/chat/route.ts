import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/authOptions';
import { supabaseAdmin } from '@/lib/supabaseServer';
import { ensureProfile } from '@/lib/ensureProfile';

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return new NextResponse('Unauthorized', { status: 401 });
    }

    const { message, conversationId } = await req.json();
    const userId = (session.user as any).id;

    // Ensure user profile exists in Supabase
    await ensureProfile({
      id: userId,
      name: session.user.name || '',
      email: session.user.email || '',
