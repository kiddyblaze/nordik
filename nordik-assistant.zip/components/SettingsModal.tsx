import React, { useState, useEffect } from 'react';
import { X, Key, Save, Database, Terminal, ExternalLink } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (apiKey: string, versionId: string) => void;
  currentApiKey: string;
  currentVersionId: string;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, onSave, currentApiKey, currentVersionId }) => {
  const [activeTab, setActiveTab] = useState<'voiceflow' | 'env'>('voiceflow');
  const [apiKey, setApiKey] = useState(currentApiKey);
  const [versionId, setVersionId] = useState(currentVersionId);

  useEffect(() => {
    if (isOpen) {
      setApiKey(currentApiKey);
      setVersionId(currentVersionId);
    }
  }, [isOpen, currentApiKey, currentVersionId]);

  const handleSave = () => {
    onSave(apiKey.trim(), versionId.trim());
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-nordik-dark/80 backdrop-blur-sm transition-opacity animate-fade-in">
      <div className="bg-white dark:bg-nordik-dark-surface w-full max-w-2xl rounded-2xl shadow-2xl border border-gray-100 dark:border-white/10 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 dark:border-white/5 flex items-center justify-between bg-nordik-light/50 dark:bg-white/5">
          <div className="flex items-center gap-2">
            <div className="bg-nordik-dark dark:bg-nordik-ivory text-white dark:text-nordik-dark p-1.5 rounded-lg">
               <Key size={16} />
            </div>
            <h2 className="text-lg font-semibold text-nordik-dark dark:text-nordik-ivory">Configuration</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-100 dark:border-white/5">
          <button 
            onClick={() => setActiveTab('voiceflow')}
            className={`flex-1 py-3 text-sm font-medium transition-colors border-b-2 ${
              activeTab === 'voiceflow' 
                ? 'border-nordik-taupe text-nordik-dark dark:text-nordik-ivory bg-gray-50 dark:bg-white/5' 
                : 'border-transparent text-gray-500 hover:text-nordik-dark dark:hover:text-nordik-light'
            }`}
          >
            Voiceflow (Live Test)
          </button>
          <button 
             onClick={() => setActiveTab('env')}
             className={`flex-1 py-3 text-sm font-medium transition-colors border-b-2 ${
              activeTab === 'env' 
                ? 'border-nordik-taupe text-nordik-dark dark:text-nordik-ivory bg-gray-50 dark:bg-white/5' 
                : 'border-transparent text-gray-500 hover:text-nordik-dark dark:hover:text-nordik-light'
            }`}
          >
            Local .env Setup
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto">
          
          {activeTab === 'voiceflow' && (
            <div className="space-y-5">
              <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-800/50 flex gap-3">
                <div className="shrink-0 mt-0.5 text-blue-600 dark:text-blue-400">
                  <Database size={18} />
                </div>
                <div className="text-sm text-blue-800 dark:text-blue-300 leading-relaxed">
                  <p className="font-semibold mb-1">Testing Mode</p>
                  Enter your Voiceflow API Key below to connect this preview directly to your agent. The Supabase database is currently simulated.
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400">Voiceflow API Key</label>
                <input 
                  type="password" 
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  placeholder="VF.DM.xxxx..."
                  className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:border-nordik-taupe focus:ring-2 focus:ring-nordik-taupe/20 outline-none text-nordik-dark dark:text-nordik-ivory transition-all text-sm font-mono"
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-wider text-gray-500 dark:text-gray-400">Version ID (Optional)</label>
                <input 
                  type="text" 
                  value={versionId}
                  onChange={(e) => setVersionId(e.target.value)}
                  placeholder="production"
                  className="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-white/10 focus:border-nordik-taupe focus:ring-2 focus:ring-nordik-taupe/20 outline-none text-nordik-dark dark:text-nordik-ivory transition-all text-sm"
                />
              </div>
            </div>
          )}

          {activeTab === 'env' && (
            <div className="space-y-5">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                To run the full stack app with real Supabase persistence and Google Auth, create a <code className="px-1 py-0.5 bg-gray-100 dark:bg-white/10 rounded font-mono text-nordik-dark dark:text-nordik-ivory">.env.local</code> file in your project root:
              </p>
              
              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-nordik-taupe to-nordik-clay opacity-20 blur rounded-xl"></div>
                <pre className="relative bg-gray-900 text-gray-300 p-4 rounded-xl text-xs font-mono overflow-x-auto leading-loose">
{`# Authentication (NextAuth.js)
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
NEXTAUTH_SECRET=your_random_secret_string
NEXTAUTH_URL=http://localhost:3000

# Database (Supabase)
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key

# AI Brain (Voiceflow)
VF_API_KEY=${apiKey || 'your_voiceflow_api_key'}
VF_VERSION_ID=${versionId || 'production'}`}
                </pre>
                <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                        onClick={() => navigator.clipboard.writeText(document.querySelector('pre')?.textContent || '')}
                        className="bg-white/10 hover:bg-white/20 text-white px-2 py-1 rounded text-[10px]"
                    >
                        Copy
                    </button>
                </div>
              </div>
              
              <div className="flex gap-4 pt-2">
                <a href="https://supabase.com/dashboard" target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-xs font-medium text-nordik-taupe hover:underline">
                    <ExternalLink size={12} /> Get Supabase Keys
                </a>
                <a href="https://console.cloud.google.com/" target="_blank" rel="noreferrer" className="flex items-center gap-1.5 text-xs font-medium text-nordik-taupe hover:underline">
                    <ExternalLink size={12} /> Get Google Keys
                </a>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-gray-50 dark:bg-white/5 flex justify-end gap-3">
          <button 
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 rounded-lg transition-colors"
          >
            Close
          </button>
          {activeTab === 'voiceflow' && (
            <button 
                onClick={handleSave}
                className="px-4 py-2 text-sm font-medium bg-nordik-dark dark:bg-nordik-ivory text-white dark:text-nordik-dark rounded-lg hover:opacity-90 transition-opacity flex items-center gap-2 shadow-lg shadow-nordik-taupe/10"
            >
                <Save size={16} />
                Save & Connect
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;