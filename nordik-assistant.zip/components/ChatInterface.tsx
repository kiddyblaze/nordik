import React, { useState, useEffect, useRef } from 'react';
import { signOut } from 'next-auth/react';
import { Conversation, Message, UserProfile } from '../types';
import Sidebar from './Sidebar';
import MessageBubble from './MessageBubble';
import VoiceInput from './VoiceInput';
import { Send, Menu, Sparkles } from 'lucide-react';

interface ChatInterfaceProps {
  user: {
    name?: string | null;
    email?: string | null;
    image?: string | null;
  };
}

export default function ChatInterface({ user }: ChatInterfaceProps) {
  // State: Chat Data
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  
  // State: UI & Inputs
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Theme Management
  useEffect(() => {
    if (isDarkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [isDarkMode]);

  const toggleTheme = () => setIsDarkMode(!isDarkMode);

  // Initial Data Fetch (Conversations)
  useEffect(() => {
    fetchConversations();
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isSending]);

  // --- API Calls ---

  const fetchConversations = async () => {
    try {
      const res = await fetch('/api/conversations');
      if (res.ok) {
        const data = await res.json();
        setConversations(data.conversations || []);
      }
    } catch (error) {
      console.error('Failed to load conversations', error);
    }
  };

  const fetchMessages = async (convId: string) => {
    try {
      setMessages([]); // Clear previous messages while loading
      const res = await fetch(`/api/messages?conversationId=${convId}`);
      if (res.ok) {
        const data = await res.json();
        setMessages(data.messages || []);
      }
    } catch (error) {
      console.error('Failed to load messages', error);
    }
  };

  // --- Event Handlers ---

  const handleNewChat = () => {
    setActiveConversationId(null);
    setMessages([]);
    setIsSidebarOpen(false);
  };

  const handleSelectConversation = (id: string) => {
    setActiveConversationId(id);
    fetchMessages(id);
    setIsSidebarOpen(false);
  };

  const handleSendMessage = async () => {
    if (!inputText.trim() || isSending) return;

    const tempId = Date.now().toString();
    const content = inputText;
    
    // 1. Optimistic UI Update
    const userMsg: Message = {
      id: tempId,
      role: 'user',
      content: content,
      created_at: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsSending(true);

    try {
      // 2. Call Backend API
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: content,
          conversationId: activeConversationId
        })
      });

      if (!response.ok) throw new Error('Failed to send message');

      const data = await response.json();

      // 3. Handle Response
      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.reply,
        created_at: new Date().toISOString()
      };

      setMessages(prev => [...prev, assistantMsg]);

      // 4. If new conversation, update ID and sidebar
      if (!activeConversationId && data.conversationId) {
        setActiveConversationId(data.conversationId);
        await fetchConversations(); // Refresh sidebar to show new title
      }

    } catch (error) {
      console.error(error);
      // Show error bubble
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "I'm having trouble connecting to the server right now. Please try again.",
        created_at: new Date().toISOString()
      }]);
    } finally {
      setIsSending(false);
    }
  };

  const userProfile: UserProfile = {
    id: 'current-user',
    name: user.name || 'User',
    email: user.email || '',
    avatar_url: user.image || undefined
  };

  return (
    <div className="flex h-screen bg-nordik-ivory dark:bg-nordik-dark overflow-hidden transition-colors duration-500">
      
      {/* Sidebar */}
      <Sidebar 
        isOpen={isSidebarOpen}
        conversations={conversations}
        activeId={activeConversationId}
        onSelect={handleSelectConversation}
        onNewChat={handleNewChat}
        user={{ name: user.name || 'User', email: user.email || '', image: user.image }}
        onLogout={() => signOut()}
        isDarkMode={isDarkMode}
        toggleTheme={toggleTheme}
      />

      {/* Mobile Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-nordik-dark/80 backdrop-blur-sm z-30 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Main Area */}
      <div className="flex-1 flex flex-col h-full relative">
        
        {/* Mobile Header */}
        <div className="md:hidden h-16 flex items-center justify-between px-4 bg-nordik-light/90 dark:bg-nordik-dark-surface/90 backdrop-blur-md border-b border-gray-200 dark:border-white/5 shrink-0 z-20">
          <button onClick={() => setIsSidebarOpen(true)} className="text-nordik-dark dark:text-nordik-ivory p-2">
            <Menu size={24} />
          </button>
          <span className="font-semibold text-nordik-dark dark:text-nordik-ivory">Nordik AI</span>
          <div className="w-10" />
        </div>

        {/* Chat History */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 no-scrollbar scroll-smooth">
          <div className="max-w-3xl mx-auto">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-[60vh] text-center animate-fade-in">
                <div className="w-20 h-20 rounded-2xl bg-nordik-taupe/10 dark:bg-nordik-taupe/20 flex items-center justify-center mb-6 rotate-3">
                    <Sparkles className="text-nordik-taupe" size={32} />
                </div>
                <h2 className="text-3xl font-semibold text-nordik-dark dark:text-nordik-ivory mb-3">Nordik Assistant</h2>
                <p className="text-nordik-clay dark:text-nordik-taupe max-w-md leading-relaxed">
                   Ask me about product specifications, maintenance protocols, or troubleshooting.
                </p>
              </div>
            ) : (
              <>
                <div className="h-4 md:h-8"></div>
                {messages.map((msg) => (
                  <MessageBubble key={msg.id} message={msg} userProfile={userProfile} />
                ))}
                {isSending && (
                  <div className="flex justify-start mb-8 animate-pulse">
                    <div className="bg-white dark:bg-nordik-dark-surface px-5 py-4 rounded-2xl rounded-tl-none shadow-sm border border-gray-100 dark:border-white/5">
                      <div className="flex gap-1.5">
                        <div className="w-1.5 h-1.5 bg-nordik-taupe rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                        <div className="w-1.5 h-1.5 bg-nordik-taupe rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                        <div className="w-1.5 h-1.5 bg-nordik-taupe rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} className="h-4" />
              </>
            )}
          </div>
        </div>

        {/* Input Bar */}
        <div className="shrink-0 p-4 md:p-6 bg-gradient-to-t from-nordik-ivory via-nordik-ivory/95 to-transparent dark:from-nordik-dark dark:via-nordik-dark/95">
          <div className="max-w-3xl mx-auto bg-white dark:bg-nordik-dark-surface rounded-[20px] shadow-xl shadow-nordik-taupe/5 dark:shadow-none p-2 pl-4 flex items-end gap-3">
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder="Ask Nordik Assistant..."
              className="w-full bg-transparent border-none focus:ring-0 resize-none py-3.5 px-0 max-h-32 text-nordik-dark dark:text-nordik-ivory placeholder-gray-400 dark:placeholder-gray-500 text-base"
              rows={1}
              style={{ minHeight: '52px' }}
            />
            <div className="flex gap-2 pb-2 pr-2">
              <VoiceInput onTranscript={(text) => setInputText(prev => prev + (prev ? ' ' : '') + text)} />
              <button 
                onClick={handleSendMessage}
                disabled={!inputText.trim() || isSending}
                className={`p-3 rounded-xl transition-all duration-200 transform ${
                  inputText.trim() && !isSending
                    ? 'bg-nordik-dark text-white hover:bg-nordik-taupe active:scale-95 dark:bg-nordik-taupe dark:hover:bg-nordik-clay'
                    : 'bg-gray-100 text-gray-400 dark:bg-white/5 dark:text-gray-600'
                }`}
              >
                <Send size={20} className={inputText.trim() && !isSending ? "ml-0.5" : ""} />
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}