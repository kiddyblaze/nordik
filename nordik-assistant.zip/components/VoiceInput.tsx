import React, { useState, useEffect, useCallback } from 'react';
import { Mic, MicOff } from 'lucide-react';

interface VoiceInputProps {
  onTranscript: (text: string) => void;
  isListening?: boolean;
}

const VoiceInput: React.FC<VoiceInputProps> = ({ onTranscript }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recog = new SpeechRecognition();
        recog.continuous = false;
        recog.interimResults = false;
        recog.lang = 'en-US';
        setRecognition(recog);
      }
    }
  }, []);

  const toggleRecording = useCallback(() => {
    if (!recognition) {
      alert("Voice recognition not supported in this browser.");
      return;
    }

    if (isRecording) {
      recognition.stop();
      setIsRecording(false);
    } else {
      recognition.start();
      setIsRecording(true);

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        onTranscript(transcript);
        setIsRecording(false);
      };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error", event.error);
        setIsRecording(false);
      };

      recognition.onend = () => {
        setIsRecording(false);
      };
    }
  }, [isRecording, recognition, onTranscript]);

  return (
    <button
      onClick={toggleRecording}
      className={`p-3 rounded-xl transition-all duration-300 ${
        isRecording 
          ? 'bg-red-500/10 text-red-500 ring-1 ring-red-500 animate-pulse' 
          : 'text-gray-400 hover:bg-gray-100 hover:text-nordik-dark dark:text-gray-500 dark:hover:bg-white/10 dark:hover:text-nordik-ivory'
      }`}
      title="Voice Input"
    >
      {isRecording ? <MicOff size={20} /> : <Mic size={20} />}
    </button>
  );
};

export default VoiceInput;