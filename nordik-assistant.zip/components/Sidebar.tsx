import React from 'react';
import { Conversation } from '../types';
import { Plus, MessageSquare, LogOut, Sun, Moon, ChevronRight, Settings } from 'lucide-react';

interface SidebarProps {
  conversations: Conversation[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onNewChat: () => void;
  user: { name: string; email: string; image?: string | null; avatar_url?: string };
  onLogout: () => void;
  isOpen: boolean;
  isDarkMode: boolean;
  toggleTheme: () => void;
  onOpenSettings?: () => void;
  hasApiKey?: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  conversations, 
  activeId, 
  onSelect, 
  onNewChat, 
  user, 
  onLogout,
  isOpen,
  isDarkMode,
  toggleTheme,
  onOpenSettings,
  hasApiKey
}) => {
  const userImage = user.avatar_url || user.image;

  return (
    <div className={`fixed inset-y-0 left-0 z-40 w-72 bg-nordik-light dark:bg-nordik-dark-sidebar border-r border-gray-200 dark:border-nordik-dark/50 transform transition-transform duration-500 cubic-bezier(0.4, 0, 0.2, 1) flex flex-col ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 shadow-xl md:shadow-none`}>
      
      {/* Header / Brand */}
      <div className="p-6 pb-4">
        <div className="mb-8 flex items-center gap-3 px-1">
             <div className="flex flex-col">
                <span className="text-3xl font-semibold text-nordik-dark dark:text-nordik-ivory leading-none tracking-tight">nordik</span>
                <span className="text-[11px] font-bold tracking-[0.35em] text-nordik-taupe dark:text-nordik-clay uppercase mt-1.5 ml-0.5">Assistant</span>
             </div>
        </div>

        <button 
          onClick={onNewChat}
          className="group w-full flex items-center justify-center gap-2.5 px-4 py-3.5 bg-nordik-dark dark:bg-nordik-ivory text-nordik-ivory dark:text-nordik-dark rounded-xl hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 ease-out"
        >
          <Plus size={18} className="stroke-[2.5]" />
          <span className="font-semibold text-sm tracking-wide">New Chat</span>
        </button>
      </div>

      {/* Conversation List */}
      <div className="flex-1 overflow-y-auto no-scrollbar px-4 py-2">
        <div className="space-y-1.5">
          <div className="px-3 py-2 text-[11px] font-bold text-nordik-clay dark:text-nordik-taupe uppercase tracking-wider opacity-80">
            History
          </div>
          
          {conversations.length === 0 && (
            <div className="px-3 text-sm text-gray-400 dark:text-gray-600 italic font-light">No conversations yet.</div>
          )}

          {conversations.map((conv) => {
            const isActive = activeId === conv.id;
            return (
              <button
                key={conv.id}
                onClick={() => onSelect(conv.id)}
                className={`group w-full flex items-center gap-3 px-3 py-3 rounded-lg text-sm transition-all duration-200 text-left relative overflow-hidden ${
                  isActive 
                    ? 'bg-white dark:bg-nordik-dark-surface text-nordik-dark dark:text-nordik-ivory shadow-sm' 
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-white/5 hover:text-nordik-dark dark:hover:text-nordik-light'
                }`}
              >
                {isActive && (
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-nordik-taupe rounded-r-full" />
                )}
                <MessageSquare 
                  size={16} 
                  className={`transition-colors ${isActive ? 'text-nordik-taupe' : 'text-gray-400 group-hover:text-nordik-clay dark:text-gray-600 dark:group-hover:text-nordik-taupe'}`} 
                />
                <span className="truncate flex-1 font-medium">{conv.title || 'New Conversation'}</span>
                {isActive && <ChevronRight size={14} className="text-nordik-taupe opacity-50" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* User Footer */}
      <div className="p-4 m-2 mt-0 bg-white dark:bg-nordik-dark-surface/50 rounded-xl border border-gray-100 dark:border-white/5 shadow-sm dark:shadow-none backdrop-blur-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
                {userImage ? (
                    <img src={userImage} alt="User" className="w-9 h-9 rounded-full bg-nordik-taupe object-cover ring-2 ring-white dark:ring-nordik-dark" />
                ) : (
                    <div className="w-9 h-9 rounded-full bg-nordik-taupe flex items-center justify-center text-white font-bold shadow-sm">
                        {user.name ? user.name.charAt(0) : 'U'}
                    </div>
                )}
                <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-white dark:border-nordik-dark-surface rounded-full"></div>
            </div>
            
            <div className="flex flex-col overflow-hidden">
              <span className="text-sm font-semibold text-nordik-dark dark:text-nordik-ivory truncate max-w-[90px]">{user.name?.split(' ')[0] || 'User'}</span>
              <span className="text-[10px] text-gray-500 dark:text-gray-400 truncate uppercase tracking-wide">Online</span>
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            {onOpenSettings && (
              <button 
                  onClick={onOpenSettings} 
                  className={`p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-white/10 transition-all relative ${!hasApiKey ? 'text-nordik-taupe' : 'text-gray-400 hover:text-nordik-dark dark:text-gray-500 dark:hover:text-nordik-ivory'}`}
                  title="Settings"
              >
                  <Settings size={18} />
                  {hasApiKey === false && <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white dark:border-nordik-dark-surface animate-pulse"></span>}
              </button>
            )}
            <button 
                onClick={toggleTheme} 
                className="text-gray-400 hover:text-nordik-taupe dark:text-gray-500 dark:hover:text-nordik-ivory p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-white/10 transition-all" 
                title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
                {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <button onClick={onLogout} className="text-gray-400 hover:text-red-500 dark:text-gray-500 dark:hover:text-red-400 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-white/10 transition-all" title="Logout">
                <LogOut size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;