import React, { useState } from 'react';
import { Message, UserProfile } from '../types';
import { User, Bot, Copy, Check } from 'lucide-react';

interface MessageBubbleProps {
  message: Message;
  userProfile?: UserProfile;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message, userProfile }) => {
  const isUser = message.role === 'user';
  const [isCopied, setIsCopied] = useState(false);

  const handleCopy = () => {
    if (!message.content) return;
    navigator.clipboard.writeText(message.content);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // --- Markdown Parser Logic ---

  const parseInlineStyles = (text: string) => {
    // Split by bold syntax (**text**)
    const parts = text.split(/(\*\*[^*]+\*\*)/g);
    return parts.map((part, index) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong 
            key={index} 
            className={`font-bold ${isUser ? 'text-white' : 'text-nordik-dark dark:text-white'}`}
          >
            {part.slice(2, -2)}
          </strong>
        );
      }
      return part;
    });
  };

  const renderFormattedContent = (content: string) => {
    const lines = content.split('\n');
    const elements: React.ReactNode[] = [];
    let currentListItems: React.ReactNode[] = [];

    const flushList = (keyPrefix: string) => {
      if (currentListItems.length > 0) {
        elements.push(
          <ul key={`${keyPrefix}-list`} className="list-disc pl-5 mb-3 space-y-1 marker:text-nordik-taupe">
            {[...currentListItems]}
          </ul>
        );
        currentListItems = [];
      }
    };

    lines.forEach((line, index) => {
      const trimmed = line.trim();
      const key = `line-${index}`;

      // 1. Handle Headers (###)
      if (trimmed.startsWith('### ')) {
        flushList(key);
        elements.push(
          <h3 key={key} className={`text-base md:text-lg font-bold mt-5 mb-2 leading-tight ${isUser ? 'text-white' : 'text-nordik-dark dark:text-white'}`}>
            {parseInlineStyles(trimmed.substring(4))}
          </h3>
        );
      } 
      // 2. Handle Subheaders (##)
      else if (trimmed.startsWith('## ')) {
        flushList(key);
        elements.push(
          <h2 key={key} className={`text-lg md:text-xl font-bold mt-6 mb-3 leading-tight ${isUser ? 'text-white' : 'text-nordik-dark dark:text-white'}`}>
            {parseInlineStyles(trimmed.substring(3))}
          </h2>
        );
      }
      // 3. Handle Lists (- or *)
      else if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
        const content = trimmed.substring(2);
        currentListItems.push(
          <li key={key} className="pl-1">
            {parseInlineStyles(content)}
          </li>
        );
      }
      // 4. Handle Empty Lines
      else if (trimmed === '') {
        flushList(key);
        // Only add spacer if it's not the very last element to avoid huge gaps at bottom
        if (index < lines.length - 1) {
             elements.push(<div key={key} className="h-2" />);
        }
      }
      // 5. Standard Paragraphs
      else {
        flushList(key);
        elements.push(
          <p key={key} className="mb-1 leading-relaxed">
            {parseInlineStyles(line)}
          </p>
        );
      }
    });

    // Flush any remaining list items at the end
    flushList('final');

    return elements;
  };

  return (
    <div className={`flex w-full mb-8 ${isUser ? 'justify-end' : 'justify-start'} group`}>
      <div className={`flex max-w-[95%] md:max-w-[85%] lg:max-w-[75%] ${isUser ? 'flex-row-reverse' : 'flex-row'} gap-3 items-end`}>
        
        {/* Avatar */}
        <div className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center mb-1 shadow-sm overflow-hidden ${
          isUser 
            ? 'bg-nordik-dark dark:bg-nordik-taupe text-white' 
            : 'bg-white dark:bg-nordik-dark-surface text-nordik-dark dark:text-nordik-taupe border border-gray-100 dark:border-white/5'
        }`}>
          {isUser ? (
             userProfile?.avatar_url ? (
                <img src={userProfile.avatar_url} alt="Me" className="w-full h-full object-cover" />
             ) : <User size={14} />
          ) : (
            <div className="flex items-center justify-center w-full h-full bg-nordik-light dark:bg-nordik-dark-surface">
                <span className="font-bold text-[10px] tracking-tighter">NA</span>
            </div>
          )}
        </div>

        {/* Bubble */}
        <div className={`relative px-5 py-4 text-[15px] shadow-sm transition-all duration-300 ${
          isUser 
            ? 'bg-nordik-dark text-nordik-ivory rounded-2xl rounded-tr-sm dark:bg-nordik-taupe dark:text-white dark:shadow-glow' 
            : 'bg-white text-nordik-dark rounded-2xl rounded-tl-sm border border-gray-100 dark:bg-nordik-dark-surface dark:text-nordik-light dark:border-white/5'
        }`}>
          
          <div className="markdown-content">
             {renderFormattedContent(message.content)}
          </div>
          
          {/* Timestamp & Actions (Visible on hover) */}
          <div className={`absolute -bottom-6 ${isUser ? 'right-0 flex-row-reverse' : 'left-0 flex-row'} flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity`}>
            <span className="text-[10px] text-gray-300 dark:text-gray-600 whitespace-nowrap">
                {new Date(message.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
            </span>
            
            {!isUser && (
                <button 
                    onClick={handleCopy} 
                    className="p-1 text-gray-400 hover:text-nordik-taupe dark:text-gray-600 dark:hover:text-nordik-ivory transition-colors rounded-md hover:bg-gray-50 dark:hover:bg-white/5"
                    title="Copy to clipboard"
                >
                    {isCopied ? <Check size={12} /> : <Copy size={12} />}
                </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;